package com.example.food_order.utils.extension

import android.util.Log

object AppLogger {
//    //Log infor thong thuong
//
//    fun i(tag: String, msg: String){
//        if(checkBeforeLog(tag)) return
//        Log.i(tag, msg)
//    }
//
//    //Log chi tiet cho dev
//    fun d(tag: String, msg: String){
//        if(checkBeforeLog(tag)) return
//        Log.d(tag, msg)
//    }
//
//    //Log warning
//    fun w(tag: String, msg: String){
//        if(checkBeforeLog(tag)) return
//        Log.w(tag, msg)
//    }
//
//
//    //Log error
//    fun e(tag: String, msg: String){
//        if(checkBeforeLog(tag)) return
//        Log.e(tag, msg)
//    }
//
//
//    //Check truoc khi log
//    private fun checkBeforeLog(tag: String): Boolean{
//        //Neu khong o trong debugMode -> Khong log ra gi
//        if(!isDebugMode()){
//            return true
//        }
//        //neu tag quá dài -> không log (android giới hạn tag 23 kí tự)
//        if(tag.length > 22){
//            return true
//        }
//
//        return false
//    }
}