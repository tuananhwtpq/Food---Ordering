package com.example.food_order.data.api

import retrofit2.http.Body
import retrofit2.http.POST

interface FoodApiServices {


}