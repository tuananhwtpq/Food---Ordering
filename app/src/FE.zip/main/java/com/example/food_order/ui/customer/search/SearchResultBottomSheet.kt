package com.example.food_order.ui.customer.search

class SearchResultBottomSheet {
}