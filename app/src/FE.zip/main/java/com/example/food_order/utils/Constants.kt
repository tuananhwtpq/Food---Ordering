package com.example.food_order.utils

object Constants {
    const val BASE_URL = "http://172.72.49.6:8080/"
}
