package com.example.food_order.data.api

interface MainApiService {
}